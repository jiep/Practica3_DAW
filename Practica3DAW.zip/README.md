# Wikiroutes
Wikiroutes: discover, share and rate routes close to you

# Cómo instalar

Para instalar, se requiere disponer de Bower. Para instalarlo, se pueden seguir los siguientes pasos:

* Descargar node desde su página oficial https://nodejs.org/
* Instalar npm (si no viene instalado junto a node)
* Ejecutar el comando `npm install -g bower`
* Para comprobar que tenemos instalado Bower ejecutar `bower -v`. Si nos aparece el número de versión, está instalado.
* Ir a la carpeta `wikiroutes` y ejecutar el comando `bower install`. Nos instalará todas las dependencias necesarias.
* Una vez descargadas todas las dependencias, abrimos Eclipse, click derecho sobre el proyecto, `Run as > Java Application`. Nos pedirá la clase principal. Se trata de la clase `Application`. La seleccionamos y esperamos a que cargue el proyecto.
* Abrimos un navegador y escribimos `localhost:8080`. Si todo ha ido bien, tendremos la aplicación funcionando.



