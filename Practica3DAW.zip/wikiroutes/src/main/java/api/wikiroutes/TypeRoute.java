package api.wikiroutes;


public class TypeRoute {
	public static enum Type {
	    WALK,
	    BIKE,
	    HORSE,
	    BOAT
	}
}